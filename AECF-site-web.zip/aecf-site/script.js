// A.E.C.F — script partagé
// Échappe le HTML pour éviter toute injection (XSS) lors de l'affichage
// de données saisies par l'utilisateur (ex : champ "budget" libre).
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

document.addEventListener('DOMContentLoaded', function () {
  // Menu mobile
  var toggle = document.querySelector('.menu-toggle');
  var nav = document.querySelector('nav.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () { nav.classList.remove('open'); });
    });
  }

  // Accordéon FAQ
  document.querySelectorAll('.accordion-item').forEach(function (item) {
    var q = item.querySelector('.accordion-q');
    if (!q) return;
    q.addEventListener('click', function () {
      var wasOpen = item.classList.contains('open');
      document.querySelectorAll('.accordion-item').forEach(function (i) { i.classList.remove('open'); });
      if (!wasOpen) item.classList.add('open');
    });
  });

  // Formulaires (démo front-end uniquement)
  document.querySelectorAll('form[data-demo-form]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      // La demande de devis alimente aussi le suivi des demandes de l'Espace Client
      if (form.id === 'devis-form') {
        var prestationEl = document.getElementById('prestation');
        var budgetEl = document.getElementById('budget');
        var prestation = prestationEl && prestationEl.value ? prestationEl.value : 'Demande de devis';
        var budget = budgetEl ? budgetEl.value : '';
        var data = JSON.parse(localStorage.getItem('aecf_demandes') || '[]');
        var refNum = String(100 + data.length).padStart(4, '0');
        var today = new Date();
        var dateStr = String(today.getDate()).padStart(2, '0') + '/' + String(today.getMonth() + 1).padStart(2, '0') + '/' + today.getFullYear();
        data.unshift({
          ref: 'DEV-' + refNum,
          prestation: prestation + (budget ? ' (budget : ' + budget + ' FCFA)' : ''),
          date: dateStr,
          statut: 'attente'
        });
        localStorage.setItem('aecf_demandes', JSON.stringify(data));
      }

      var success = form.parentElement.querySelector('.form-success');
      if (success) success.style.display = 'block';
      form.reset();
      if (success) success.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
  });

  // ---------- Espace Client : connexion, suivi, téléchargements, historique ----------
  (function () {
    var loginForm = document.getElementById('ec-login-form');
    if (!loginForm) return; // page sans espace client

    var loginSection = document.getElementById('ec-login-section');
    var dashboard = document.getElementById('ec-dashboard');
    var welcome = document.getElementById('ec-welcome');
    var logoutBtn = document.getElementById('ec-logout');

    var KEY_SESSION = 'aecf_client_session';
    var KEY_DEMANDES = 'aecf_demandes';
    var KEY_HISTORIQUE = 'aecf_historique';

    function seedIfEmpty(key, seedData) {
      if (!localStorage.getItem(key)) {
        localStorage.setItem(key, JSON.stringify(seedData));
      }
    }
    seedIfEmpty(KEY_DEMANDES, [
      { ref: 'DEV-0014', prestation: "Formation A004 — Gestion du temps et des priorités", date: '02/03/2026', statut: 'termine' },
      { ref: 'DEV-0021', prestation: 'Étude de faisabilité — Projet agroalimentaire', date: '18/04/2026', statut: 'cours' },
      { ref: 'DEV-0029', prestation: 'Diagnostic organisationnel — PME', date: '05/06/2026', statut: 'attente' }
    ]);
    seedIfEmpty(KEY_HISTORIQUE, [
      { date: 'Nov. 2025', prestation: 'Formation en gestion du stress et efficacité professionnelle', partenaire: 'Cabinet Bangré Vénéem International (BVI)' },
      { date: 'Jan. 2026', prestation: "Formation en management, leadership et sentiment d'appartenance", partenaire: 'Secrétariat du Gouvernement' },
      { date: 'Fév. 2026', prestation: 'Activités génératrices de revenus et métiers porteurs', partenaire: 'Femmes affectées par la SEPB — Koupéla' },
      { date: 'Mars 2026', prestation: 'Techniques de mise en œuvre des conventions de partenariat', partenaire: 'Burkina Suudu Bawde (BSB)' }
    ]);

    var LABELS = { termine: 'Terminé', cours: 'En cours', attente: 'En attente' };
    var CLASSES = { termine: 'status-termine', cours: 'status-cours', attente: 'status-attente' };

    function renderDemandes() {
      var body = document.getElementById('ec-demandes-body');
      if (!body) return;
      var data = JSON.parse(localStorage.getItem(KEY_DEMANDES) || '[]');
      if (!data.length) {
        body.innerHTML = '<tr><td colspan="4" class="ec-empty">Aucune demande pour le moment.</td></tr>';
        return;
      }
      body.innerHTML = data.map(function (d) {
        return '<tr><td>' + escapeHtml(d.ref) + '</td><td>' + escapeHtml(d.prestation) + '</td><td>' + escapeHtml(d.date) + '</td>' +
          '<td><span class="status-pill ' + (CLASSES[d.statut] || '') + '">' + escapeHtml(LABELS[d.statut] || d.statut) + '</span></td></tr>';
      }).join('');
    }

    function renderHistorique() {
      var body = document.getElementById('ec-historique-body');
      if (!body) return;
      var data = JSON.parse(localStorage.getItem(KEY_HISTORIQUE) || '[]');
      body.innerHTML = data.map(function (h) {
        return '<tr><td>' + escapeHtml(h.date) + '</td><td>' + escapeHtml(h.prestation) + '</td><td>' + escapeHtml(h.partenaire) + '</td></tr>';
      }).join('');
    }

    function showDashboard(email) {
      loginSection.style.display = 'none';
      dashboard.style.display = 'block';
      welcome.textContent = 'Bonjour, ' + (email || 'cher client') + ' !';
      renderDemandes();
      renderHistorique();
    }

    // Session déjà active ?
    var existingSession = localStorage.getItem(KEY_SESSION);
    if (existingSession) showDashboard(existingSession);

    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var email = document.getElementById('cemail').value || 'cher client';
      localStorage.setItem(KEY_SESSION, email);
      showDashboard(email);
    });

    if (logoutBtn) {
      logoutBtn.addEventListener('click', function () {
        localStorage.removeItem(KEY_SESSION);
        dashboard.style.display = 'none';
        loginSection.style.display = 'block';
      });
    }

    // Onglets du tableau de bord
    document.querySelectorAll('.ec-tab').forEach(function (btn) {
      btn.addEventListener('click', function () {
        document.querySelectorAll('.ec-tab').forEach(function (b) { b.classList.remove('active'); });
        document.querySelectorAll('.ec-panel').forEach(function (p) { p.style.display = 'none'; });
        btn.classList.add('active');
        var panel = document.getElementById('ec-panel-' + btn.getAttribute('data-tab'));
        if (panel) panel.style.display = 'block';
      });
    });

    // Nouvelle demande rapide
    var newDemandeForm = document.getElementById('ec-new-demande');
    if (newDemandeForm) {
      newDemandeForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var prestation = document.getElementById('ec-prestation').value;
        var budget = document.getElementById('ec-budget').value;
        var data = JSON.parse(localStorage.getItem(KEY_DEMANDES) || '[]');
        var refNum = String(100 + data.length).padStart(4, '0');
        var today = new Date();
        var dateStr = String(today.getDate()).padStart(2, '0') + '/' + String(today.getMonth() + 1).padStart(2, '0') + '/' + today.getFullYear();
        data.unshift({
          ref: 'DEV-' + refNum,
          prestation: prestation + (budget ? ' (budget : ' + budget + ' FCFA)' : ''),
          date: dateStr,
          statut: 'attente'
        });
        localStorage.setItem(KEY_DEMANDES, JSON.stringify(data));
        renderDemandes();
        newDemandeForm.reset();
      });
    }
  })();

  // ---------- Diaporama de fond du héro (accueil) : change de photo toutes les 15 secondes ----------
  (function () {
    var slideshow = document.getElementById('hero-slideshow');
    if (!slideshow) return;
    var slides = slideshow.querySelectorAll('.hero-bg-slide');
    if (slides.length < 2) return;
    var dotsWrap = document.getElementById('hero-dots');
    var dots = dotsWrap ? dotsWrap.querySelectorAll('.hero-dot') : [];
    var current = 0;
    var SLIDE_INTERVAL = 15 * 1000;

    function goTo(index) {
      slides[current].classList.remove('active');
      if (dots[current]) dots[current].classList.remove('active');
      current = index;
      slides[current].classList.add('active');
      if (dots[current]) dots[current].classList.add('active');
    }

    setInterval(function () {
      goTo((current + 1) % slides.length);
    }, SLIDE_INTERVAL);

    dots.forEach(function (dot, i) {
      dot.addEventListener('click', function () { goTo(i); });
    });
  })();

  // ---------- Carrousel "Nos réalisations" (accueil) : défilement en boucle ----------
  (function () {
    var carousel = document.getElementById('home-carousel');
    if (!carousel) return;
    var slides = carousel.querySelectorAll('.real-slide');
    if (slides.length < 2) return;
    var dotsWrap = document.getElementById('home-carousel-dots');
    var dots = dotsWrap ? dotsWrap.querySelectorAll('.real-dot') : [];
    var current = 0;
    var CAROUSEL_INTERVAL = 5 * 1000;

    function goTo(index) {
      slides[current].classList.remove('active');
      if (dots[current]) dots[current].classList.remove('active');
      current = index;
      slides[current].classList.add('active');
      if (dots[current]) dots[current].classList.add('active');
    }

    setInterval(function () {
      goTo((current + 1) % slides.length);
    }, CAROUSEL_INTERVAL);

    dots.forEach(function (dot, i) {
      dot.addEventListener('click', function () { goTo(i); });
    });
  })();
});
